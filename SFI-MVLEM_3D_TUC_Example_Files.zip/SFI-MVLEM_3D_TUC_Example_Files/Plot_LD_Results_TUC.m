% Plots load-deformation responses for selected cycles only
% clc
clear all
close all

modelColor = 'r';
modelLineThick = 0.5;
testColor = 'k';
testLineThick = 0.5;

NoStepPerDir = 100; % Numer of increments per step

% Load Model Data
Folder = sprintf('TUC_Results');
NODE_CONTROL2950 = importdata(fullfile(Folder,'NODE_DISP_2950.out')); NODE_CONTROL2950(end,:)=[]; NODE_CONTROL2950(1:100,:)=[];
REACTIONS = importdata(fullfile(Folder,'REACTIONS_1.out')); REACTIONS(end,:)=[]; REACTIONS(1:100,:)=[];
NODE_CONTROL3350 = importdata(fullfile(Folder,'NODE_DISP_3350.out')); NODE_CONTROL3350(end,:)=[]; NODE_CONTROL3350(1:100,:)=[];

Dir = xlsread('Dtop_Input_TUC_FULL.xlsx','XY','I3:I301');

% INPUT END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Process Model Data
DtopX2950 = NODE_CONTROL2950(:,2);
DtopX2950(1:100)=[];
DtopY2950 = NODE_CONTROL2950(:,3);
DtopY2950(1:100)=[];

DtopX3350 = NODE_CONTROL3350(:,2);
DtopX3350(1:100)=[];
DtopY3350 = NODE_CONTROL3350(:,3);
DtopY3350(1:100)=[];

[nosteps,trash] = size(DtopX2950);

[nostepsR,datasizeR] = size(REACTIONS);
for i=1:nostepsR
    Rx(i) = sum(REACTIONS(i,2:6:datasizeR));
    Ry(i) = sum(REACTIONS(i,3:6:datasizeR));
end

for i=1:nostepsR
    Fx(i) = -Rx(i);
    Fy(i) = -Ry(i);
end
Fx(1:100)=[];
Fy(1:100)=[];

% Load Directions
[nodir,trash] = size(Dir);
Dirs = zeros(nodir*NoStepPerDir,1);

for i=1:nodir
    for j=1:NoStepPerDir
        Dirs((i-1)*NoStepPerDir+j,1) = Dir(i);
    end
end

%% Load Test
load EWcycle_EW_FD.txt
load NScycle_NS_FD.txt

%% Plot Results
% dX=1;dY=1;
for i=1:nosteps
    if Dirs(i) == 2 % E-F Diagonal Cycles
        EF_Fx_EW(i,1) = Fx(i);
        EF_DtopX_2950(i,1) = DtopX2950(i,1);
        EF_Fy_NS(i,1) = Fy(i);
        EF_DtopY_2950(i,1) = DtopY2950(i,1);
        GH_Fx_EW(i,1) = 0.0;
        GH_DtopX_2950(i,1) = 0.0;
        GH_Fy_NS(i,1) = 0.0;
        GH_DtopY_2950(i,1) = 0.0;
        EW_Fx_EW(i,1) = 0.0;
        EW_DtopX_2950(i,1) = 0.0;
        EW_Fy_NS(i,1) = 0.0;
        EW_DtopY_2950(i,1) = 0.0;
        NS_Fx_EW(i,1) = 0.0;
        NS_DtopX_2950(i,1) = 0.0;
        NS_Fy_NS(i,1) = 0.0;
        NS_DtopY_2950(i,1) = 0.0;
        %         dX = dX+1;
    elseif Dirs(i) == 3 % G-H Diagonal Cycles
        GH_Fx_EW(i,1) = Fx(i);
        GH_DtopX_2950(i,1) = DtopX2950(i,1);
        GH_Fy_NS(i,1) = Fy(i);
        GH_DtopY_2950(i,1) = DtopY2950(i,1);
        EF_Fx_EW(i,1) = 0.0;
        EF_DtopX_2950(i,1) = 0.0;
        EF_Fy_NS(i,1) = 0.0;
        EF_DtopY_2950(i,1) = 0.0;
        EW_Fx_EW(i,1) = 0.0;
        EW_DtopX_2950(i,1) = 0.0;
        EW_Fy_NS(i,1) = 0.0;
        EW_DtopY_2950(i,1) = 0.0;
        NS_Fx_EW(i,1) = 0.0;
        NS_DtopX_2950(i,1) = 0.0;
        NS_Fy_NS(i,1) = 0.0;
        NS_DtopY_2950(i,1) = 0.0;
        %         dY = dY+1;
    elseif Dirs(i) == 10 % E-W cycles
        EF_Fx_EW(i,1) = 0.0;
        EF_DtopX_2950(i,1) = 0.0;
        EF_Fy_NS(i,1) = 0.0;
        EF_DtopY_2950(i,1) = 0.0;
        GH_Fx_EW(i,1) = 0.0;
        GH_DtopX_2950(i,1) = 0.0;
        GH_Fy_NS(i,1) = 0.0;
        GH_DtopY_2950(i,1) = 0.0;
        EW_Fx_EW(i,1) = Fx(i);
        EW_DtopX_2950(i,1) = DtopX3350(i,1);
        EW_Fy_NS(i,1) = 0.0;
        EW_DtopY_2950(i,1) = 0.0;
        NS_Fx_EW(i,1) = 0.0;
        NS_DtopX_2950(i,1) = 0.0;
        NS_Fy_NS(i,1) = 0.0;
        NS_DtopY_2950(i,1) = 0.0;
        %         dY = dY+1;
    else % Dirs(i) == 20 % N-S cycles
        EF_Fx_EW(i,1) = 0.0;
        EF_DtopX_2950(i,1) = 0.0;
        EF_Fy_NS(i,1) = 0.0;
        EF_DtopY_2950(i,1) = 0.0;
        GH_Fx_EW(i,1) = 0.0;
        GH_DtopX_2950(i,1) = 0.0;
        GH_Fy_NS(i,1) = 0.0;
        GH_DtopY_2950(i,1) = 0.0;
        EW_Fx_EW(i,1) = 0.0;
        EW_DtopX_2950(i,1) = 0.0;
        EW_Fy_NS(i,1) = 0.0;
        EW_DtopY_2950(i,1) = 0.0;
        NS_Fx_EW(i,1) = 0.0;
        NS_DtopX_2950(i,1) = 0.0;
        NS_Fy_NS(i,1) = Fy(i);
        NS_DtopY_2950(i,1) = DtopY2950(i,1);
        %         dY = dY+1;
    end
end

%% SRSS Calculations

%SRSS direction
for i=1:nosteps
    FixNaN(i,1) = EF_DtopY_2950(i,1) + GH_DtopY_2950(i,1);
    if FixNaN(i,1) == 0
        SRSS_Dir(i,1) = 0;
    else if EF_DtopY_2950(i,1) == 0
            SRSS_Dir(i,1) = GH_DtopY_2950(i,1)/abs(GH_DtopY_2950(i,1));
        else
            SRSS_Dir(i,1) = EF_DtopY_2950(i,1)/abs(EF_DtopY_2950(i,1));
        end
    end
end

%SRSS displacement
EF_DtopX_2950_sq = EF_DtopX_2950.^2;
EF_DtopY_2950_sq = EF_DtopY_2950.^2;
GH_DtopX_2950_sq = GH_DtopX_2950.^2;
GH_DtopY_2950_sq = GH_DtopY_2950.^2;

for i=1:nosteps
    SRSS_Disp_EF(i,1) = sqrt(EF_DtopX_2950_sq(i,1) + EF_DtopY_2950_sq(i,1))*SRSS_Dir(i,1);
    SRSS_Disp_GH(i,1) = sqrt(GH_DtopX_2950_sq(i,1) + GH_DtopY_2950_sq(i,1))*SRSS_Dir(i,1);
end

%SRSS force
EF_Fx_EW_sq = EF_Fx_EW.^2;
EF_Fy_NS_sq = EF_Fy_NS.^2;
GH_Fx_EW_sq = GH_Fx_EW.^2;
GH_Fy_NS_sq = GH_Fy_NS.^2;

for i=1:nosteps
    SRSS_Force_EF(i,1) = sqrt(EF_Fx_EW_sq(i,1) + EF_Fy_NS_sq(i,1))*SRSS_Dir(i,1);
    SRSS_Force_GH(i,1) = sqrt(GH_Fx_EW_sq(i,1) + GH_Fy_NS_sq(i,1))*SRSS_Dir(i,1);
end

%% Plot
gcf = figure(1)
subplot(2,2,1)
plot([0 0],[-200 200],'k','LineWidth',0.2)
hold on
plot([-4 4],[0 0],'k','LineWidth',0.2)
Test = plot(EWcycle_EW_FD(:,1)/25.4,EWcycle_EW_FD(:,2)*0.224808943871,testColor,'Linewidth',testLineThick);
hold on
Model = plot(EW_DtopX_2950(:,1),EW_Fx_EW(:,1),modelColor,'Linewidth',modelLineThick);
hold off
axis([-3 3 -125 125])
xlabel('EW Displacement at h = 3.35 m (in)')
ylabel('EW Force (kip)')
title('a) Load-Deformation in East-West Dir.')

legend('Location','southeast')
legend('boxoff')
hA=gca;
hA.XMinorTick = 'on';
hA.YMinorTick = 'on';
lg = legend([Test Model], 'Test','Model');


subplot(2,2,2)
plot([0 0],[-200 200],'k','LineWidth',0.2)
hold on
plot([-4 4],[0 0],'k','LineWidth',0.2)
Test = plot(NScycle_NS_FD(:,1)/25.4,NScycle_NS_FD(:,2)*0.224808943871,testColor,'Linewidth',testLineThick);
hold on
Model = plot(NS_DtopY_2950(:,1),NS_Fy_NS(:,1),modelColor,'Linewidth',modelLineThick);
hold off
axis([-3 3 -125 125])
xlabel('NS Displacement at h = 2.95 m (in)')
ylabel('NS Force (kip)')
title('b) Load-Deformation in North-South Dir.')
legend('Test','Model')

legend('Location','southeast')
legend('boxoff')
hA=gca;
hA.XMinorTick = 'on';
hA.YMinorTick = 'on';
lg = legend([Test Model], 'Test','Model');


subplot(2,2,3)
c=imread('TUC_SRSSForce_EF_clean.jpg');
imagesc([-3.14961 3.14961], [-179.847 179.847], c);
hold on
Test = plot([0 0],[-200 200],'k','LineWidth',0.2);
plot([-4 4],[0 0],'k','LineWidth',0.2)
Model = plot(SRSS_Disp_EF(:,1),-SRSS_Force_EF(:,1),modelColor,'Linewidth',modelLineThick);
hold off
axis([-3.14961 3.14961 -179.847 179.847])
xlabel('SRSS Displacement at h = 2.95 m (in)')
ylabel('SRSS Force (kip)')
title('c) SRSS Force-Displacement in E-F Dir.')

legend('Location','southeast')
legend('boxoff')
hA=gca;
hA.XMinorTick = 'on';
hA.YMinorTick = 'on';
lg = legend([Test Model], 'Test','Model');


subplot(2,2,4)
c=imread('TUC_SRSSForce_GH_clean.jpg');
imagesc([-3.14961 3.14961], [-179.847 179.847], c);
hold on
Test = plot([0 0],[-200 200],'k','LineWidth',0.2);
plot([-4 4],[0 0],'k','LineWidth',0.2)
Model = plot(SRSS_Disp_GH(:,1),-SRSS_Force_GH(:,1),modelColor,'Linewidth',modelLineThick);
hold off
axis([-3.14961 3.14961 -179.847 179.847])
xlabel('SRSS Displacement at h = 2.95 m (in)')
ylabel('SRSS Force (kip)')
title('d) SRSS Force-Displacement in G-H Dir.')
legend('Location','southeast')
legend('boxoff')
hA=gca;
hA.XMinorTick = 'on';
hA.YMinorTick = 'on';
lg = legend([Test Model], 'Test','Model');

%%
x0=50;
y0=50;
width=800;
height=700;
set(gcf,'Position',[x0,y0,width,height])

